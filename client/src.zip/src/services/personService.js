import api from "./api";

// Get all persons
export const getPersons = () => api.get("/person");

// Register person
export const registerPerson = (data) =>
    api.post("/person/register", data);

// Update person
export const updatePerson = (id, data) =>
    api.put(`/person/${id}`, data);

// Delete person
export const deletePerson = (id) =>
    api.delete(`/person/${id}`);