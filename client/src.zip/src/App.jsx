import { BrowserRouter, Routes, Route } from "react-router-dom";

import Login from "./pages/auth/Login";
import Dashboard from "./pages/admin/Dashboard";
import RegisterPerson from "./pages/admin/RegisterPerson";
import ManagePersons from "./pages/admin/ManagePersons";
import ManageUsers from "./pages/admin/ManageUsers";
import PersonDetails from "./pages/admin/PersonDetails";
import Settings from "./pages/admin/Settings";
import RegisterOfficer from "./pages/auth/RegisterOfficer";

import UploadVideo from "./pages/UploadVideo";
import Results from "./pages/Results";

import ProtectedRoute from "./components/ProtectedRoute";
import MainLayout from "./layouts/MainLayout";

function App() {
  return (
    <BrowserRouter>
      <Routes>
  {/* Public Route */}
  <Route path="/" element={<Login />} />

  {/* Protected Routes */}
<Route element={<ProtectedRoute />}>
  <Route element={<MainLayout />}>
    <Route path="/dashboard" element={<Dashboard />} />
    <Route path="/register" element={<RegisterPerson />} />
    <Route path="/register-officer" element={<RegisterOfficer />}/>
    <Route path="/upload" element={<UploadVideo />} />
    <Route path="/results" element={<Results />} />
    <Route path="/settings" element={<Settings />} />
    <Route path="/manage-persons" element={<ManagePersons />} />
    <Route path="/manage-users" element={<ManageUsers />} />
    <Route path="/person/:id" element={<PersonDetails />} />
    <Route path="/person/edit/:id" element={<RegisterPerson />} />
 
  </Route>
</Route>
</Routes>
    </BrowserRouter>
  );
}

export default App;