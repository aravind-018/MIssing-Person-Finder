import { Outlet } from "react-router-dom";
import OfficerSidebar from "../components/OfficerSidebar";
import "./MainLayout.css";

function MainLayout() {
  return (
    <div className="main-layout">
      <OfficerSidebar />

      <main className="page-content">
        <Outlet />
      </main>
    </div>
  );
}

export default MainLayout;