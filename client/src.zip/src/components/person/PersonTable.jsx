import "./PersonTable.css";

function PersonTable({ persons, onDelete }) {
  return (
    <div className="table-container">
      <table className="person-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Contact</th>
            <th>Address</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {persons.map((person) => (
            <tr key={person._id}>
              <td>{person.name}</td>
              <td>{person.age}</td>
              <td>{person.gender}</td>
              <td>{person.contact}</td>
              <td>{person.address}</td>

              <td>
                <button className="edit-btn">Edit</button>
                <button
    className="delete-btn"
    onClick={() => onDelete(person._id)}
>
    Delete
</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default PersonTable;