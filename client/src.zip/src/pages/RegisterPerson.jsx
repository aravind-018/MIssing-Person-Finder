import { useState } from "react";
import Sidebar from "../components/Sidebar";
import "../styles/RegisterPerson.css";
import api from "../services/api";

function RegisterPerson() {
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "",
    address: "",
    contact: "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await api.post("/person/register", formData);

      alert("Person Registered Successfully!");

      console.log(response.data);

      setFormData({
        name: "",
        age: "",
        gender: "",
        address: "",
        contact: "",
      });
    } catch (error) {
      console.error(error);
      alert("Registration Failed");
    }
  };

  return (
    <div className="page">
      <Sidebar />

      <div className="content">
        <h1>Register Missing Person</h1>

        <form className="form-card" onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Age</label>
            <input
              type="number"
              name="age"
              value={formData.age}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Gender</label>

            <select
              name="gender"
              value={formData.gender}
              onChange={handleChange}
              required
            >
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div className="form-group">
            <label>Address</label>

            <textarea
              rows="4"
              name="address"
              value={formData.address}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Contact Number</label>

            <input
              type="text"
              name="contact"
              value={formData.contact}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Upload Photo</label>

            <input type="file" disabled />
          </div>

          <button type="submit" className="submit-btn">
            Register Person
          </button>
        </form>
      </div>
    </div>
  );
}

export default RegisterPerson;