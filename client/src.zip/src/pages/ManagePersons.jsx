import { useEffect, useState } from "react";
import {
  getAllPersons,
  deletePerson,
} from "../services/personService";
import PersonTable from "../components/person/PersonTable";

function ManagePersons() {
  const [persons, setPersons] = useState([]);



async function handleDelete(id) {
  const confirmDelete = window.confirm(
    "Are you sure you want to delete this person?"
  );

  if (!confirmDelete) return;

  try {
    await deletePerson(id);

    setPersons((prevPersons) =>
      prevPersons.filter((person) => person._id !== id)
    );
  } catch (error) {
    console.error(error);
  }
}

  // 2. Then useEffect
useEffect(() => {
  (async () => {
    try {
      const data = await getAllPersons();
      setPersons(data);
    } catch (error) {
      console.error(error);
    }
  })();
}, []);
  // 3. Then return
  return (
    <div style={{ padding: "30px" }}>
      <h1>Manage Missing Persons</h1>

      <PersonTable
        persons={persons}
        onDelete={handleDelete}
      />
    </div>
  );
}
export default ManagePersons;